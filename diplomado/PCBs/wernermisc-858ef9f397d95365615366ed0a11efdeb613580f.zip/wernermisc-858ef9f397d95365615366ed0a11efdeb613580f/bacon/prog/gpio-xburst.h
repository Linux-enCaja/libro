/* 
 * gpio-xburst.h - Really primitive XBurst GPIO access
 *
 * Written 2010 by Werner Almesberger
 * Copyright 2010 Werner Almesberger
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 */

/*
 * Ports are numbered 0 = A, 1 = B, ...
 */


#ifndef GPIO_XBURST_H
#define GPIO_XBURST_H


#include <stdint.h>


volatile void *mem;


#define	REG(off) (*(volatile uint32_t *) (mem+(off)))

#define port_pin(port) REG(port*0x100)
#define port_dats(port) REG(port*0x100+0x14)
#define port_datc(port) REG(port*0x100+0x18)
#define port_func(port) REG(port*0x100+0x48)
#define port_dirs(port) REG(port*0x100+0x64)
#define port_dirc(port) REG(port*0x100+0x68)


static inline void gpio_high(unsigned port, unsigned bit)
{
	port_dats(port) = 1 << bit;
}


static inline void gpio_low(unsigned port, unsigned bit)
{
	port_datc(port) = 1 << bit;
}


static inline void gpio_set(unsigned port, unsigned bit, int value)
{
	if (value)
		gpio_high(port, bit);
	else
		gpio_low(port, bit);
}


static inline int gpio_get(unsigned port, unsigned bit)
{
	return (port_pin(port) >> bit) & 1;
}


static inline void gpio_output(unsigned port, unsigned bit)
{
	port_dirs(port) = 1 << bit;
}


static inline void gpio_input(unsigned port, unsigned bit)
{
	port_dirc(port) = 1 << bit;
}


void gpio_init(void);


#endif /* !GPIO_XBURST_H */
