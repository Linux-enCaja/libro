#!/usr/bin/perl

if ($ARGV[0] eq "-r") {
	shift @ARGV;
	$reverse = 1;
}

$x0 = shift @ARGV;
$y0 = shift @ARGV;
$x1 = shift @ARGV;
$y1 = shift @ARGV;

while (<>) {
	$z{$1} = 1 if /\s+(-?\d+(\.\d*)?)\s*$/;
	$zmax = $1 if $1 > $zmax || !defined $zmax;
}

if ($reverse) {         
	($x0, $y0) = ($y0, $x0);
	($x1, $y1) = ($y1, $x1);
}

for (keys %z) {
	print "$x0 $y0 $_\n";
	print "$x1 $y0 $_\n";
	print "$x1 $y1 $_\n";
	print "$x0 $y1 $_\n";
	print "$x0 $y0 $_\n\n";
}
