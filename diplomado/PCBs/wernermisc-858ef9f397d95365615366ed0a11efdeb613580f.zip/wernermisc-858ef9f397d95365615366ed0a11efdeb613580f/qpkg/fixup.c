/*
 * fixup.c - Adjust things after parsing is done
 *
 * Written 2010 by Werner Almesberger
 * Copyright 2010 Werner Almesberger
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 */


#include <stdio.h>

#include "jrb.h"

#include "pkg.h"
#include "qpkg.h"
#include "fixup.h"


void sort_versions(void)
{
	const struct jrb *n;
	struct pkg **a, **b;
	struct pkg *tmp;

	for (n = jrb_first(packages->root); n != jrb_nil(packages->root);
	    n = jrb_next(n))
		for (a = (struct pkg **) &n->val; *a; a = &(*a)->more)
			for (b = &(*a)->more; *b;)
				if (comp_versions((*a)->version,
				    (*b)->version) >= 0)
					b = &(*b)->more;
				else {
					tmp = *a;
					*a = *b;
					*b = tmp;
					tmp = (*a)->more;
					(*a)->more = (*b)->more;
					(*b)->more = tmp;
				}
}


void complete_provisions(void)
{
	struct jrb *n;

	for (n = jrb_first(packages->root); n != jrb_nil(packages->root);
	    n = jrb_next(n))
		if (!n->val)
			new_pkg(n)->flags |= QPKG_PROVIDED;
}
