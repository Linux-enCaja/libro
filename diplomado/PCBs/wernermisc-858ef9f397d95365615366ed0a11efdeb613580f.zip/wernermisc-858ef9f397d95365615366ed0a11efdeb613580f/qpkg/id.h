/*
 * id.h - Registry of unique and alphabetically sorted identifiers
 *
 * Written 2010 by Werner Almesberger
 * Copyright 2010 Werner Almesberger
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 */

#ifndef ID_H
#define	ID_H

#include <sys/types.h>

#include "jrb.h"


/*
 * The role of key and value in jrb nodes:
 *
 * - the key points to a "struct id". This "struct id" is unique for the
 *   identifier in question and its location can be used to check for equality
 *   with a simple pointer comparison.
 *
 *   A caller to find_id may therefore be interested in a pointer to the key,
 *   even if the content of the key is known.
 *
 * - for the value, we have to distinguish between packages and versions:
 *
 *   - package: pointer to the first package definition. If there are multiple
 *     packages with the same name, the rest is linked via pkg->more.
 *
 *     The value can be NULL if a reference to the package has been
 *     encountered, but
 *
 *     - the package definition has not been parsed yet,
 *     - no corresponding package definition exist (which would be an error),
 *     - the reference is an item listed in Provides: (this will change once
 *       we handle Provides: properly)
 *
 *   - version: the value is not used
 */


struct id;

struct tree {
	int (*comp)(const void *a, const void *b);
	struct jrb *root;
};

struct id {
	struct jrb *jrb;
	const char *s;
	size_t len;
};


/*
 * Helper macro for printing identifiers.
 * Use with "... %.*s ..."
 */

#define	ID2PF(id)	(int) (id)->len, (id)->s


int comp_id(const void *a, const void *b);
int comp_versions(const struct id *va, const struct id *vb);

struct tree *make_tree(int (*comp)(const void *a, const void *b));
struct jrb *make_id(struct tree *tree, const char *s, size_t len);
const struct jrb *find_id(const struct tree *tree, const char *s, size_t len);

#endif /* !ID_H */
