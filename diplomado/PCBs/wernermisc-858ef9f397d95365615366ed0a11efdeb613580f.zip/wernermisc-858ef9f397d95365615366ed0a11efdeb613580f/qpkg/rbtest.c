/*
 * rbtest.c - Very basic regression test for red-black trees
 *
 * Written 2010 by Werner Almesberger
 * Copyright 2010 Werner Almesberger
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 */


#include <stdio.h>
#include <string.h>

#include "jrb.h"



static int cmp(const void *a, const void *b)
{
	return strcmp(a, b);
}


#define	INSERT(key, val) \
	jrb_insert(tree, key, val, cmp)


int main(void)
{
	struct jrb *tree = make_jrb();
	struct jrb *p;

	INSERT("ab", "have");
	INSERT("ac", "NOT");
	INSERT("d", "little");
	INSERT("c", "this");
	INSERT("b", "passed");
	INSERT("e", "regression");
	INSERT("fa", "test");
	INSERT("aa", "We");
	INSERT("ff", "!");

	p = jrb_find(tree, "ac", cmp);
	jrb_delete_node(p);

	jrb_traverse(p, tree)
		printf("%s ", (char *) jrb_val(p));
	printf("\n");

	return 0;
}
