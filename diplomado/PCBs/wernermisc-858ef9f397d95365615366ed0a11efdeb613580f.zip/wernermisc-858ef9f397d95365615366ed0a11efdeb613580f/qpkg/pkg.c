/*
 * pkg.c - Package structure and operations
 *
 * Written 2010 by Werner Almesberger
 * Copyright 2010 Werner Almesberger
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 */


#include <stdlib.h>

#include "util.h"
#include "jrb.h"
#include "pkg.h"



struct pkg *new_pkg(struct jrb *jrb)
{
	struct pkg *pkg;

	pkg = alloc_type(struct pkg);

	pkg->id = jrb->key;
	pkg->more = jrb->val;
	jrb->val = pkg;
	pkg->version = NULL;
	pkg->arch = NULL;
	pkg->conflicts = pkg->depends = pkg->provides = NULL;
	pkg->filename = NULL;
	pkg->flags = 0;
	pkg->mark = 0;

	return pkg;
}


static void free_refs(struct ref *refs)
{
	struct ref *next;

	while (refs) {
		next = refs->next;
		free(refs);
		refs = next;
	}
}


void free_pkg(struct pkg *pkg)
{
	free_refs(pkg->conflicts);
	free_refs(pkg->depends);
	free_refs(pkg->provides);
	free(pkg);
}
