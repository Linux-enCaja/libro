/*
 * util.h - Common utility functions
 *
 * Written 2009 by Werner Almesberger
 * Copyright 2009 by Werner Almesberger
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 */

#ifndef UTIL_H
#define UTIL_H

#include <stdlib.h>


#define alloc_size(s)				\
    ({  void *alloc_size_tmp = malloc(s);	\
	if (!alloc_size_tmp)			\
		abort();			\
	alloc_size_tmp; })

#define alloc_type(t) ((t *) alloc_size(sizeof(t)))

#endif /* !UTIL_H */
