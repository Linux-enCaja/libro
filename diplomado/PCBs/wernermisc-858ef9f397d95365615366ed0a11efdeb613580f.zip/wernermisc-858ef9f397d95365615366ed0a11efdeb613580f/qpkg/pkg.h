/*
 * pkg.h - Package structure and operations
 *
 * Written 2010 by Werner Almesberger
 * Copyright 2010 Werner Almesberger
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 */

#ifndef PKG_H
#define	PKG_H

#include "jrb.h"

#include "id.h"


enum flags {
	/* parse-time and fixup-time flags */
	QPKG_INSTALLED	= 1 << 0,	/* installed on target */
	QPKG_PROVIDED	= 1 << 1,	/* virtual package */

	/* run-time flags */
	QPKG_ADDING	= 1 << 10,	/* resolving dependencies */
};

enum relop {
	rel_eq,		/* =  */
	rel_ge,		/* >= */
	rel_gg,		/* >> */
	rel_lt,		/* <  DEPRECATED */
	rel_le,		/* <= */
	rel_ll,		/* << */
};

struct pkg;

struct ref {
	struct id *pkg;
	struct id *version;
	enum relop relop;	/* undefined if version == NULL */
	struct ref *next;
};

struct pkg {
	struct id *id;
	struct id *version;
	const char *arch;
	struct ref *conflicts;
	struct ref *depends;
	struct ref *provides;
	const char *filename;
	int flags;		/* see enum flags */
	struct pkg *more;
	int mark;
};


struct pkg *new_pkg(struct jrb *jrb);
void free_pkg(struct pkg *pkg);

#endif /* !PKG_H */
