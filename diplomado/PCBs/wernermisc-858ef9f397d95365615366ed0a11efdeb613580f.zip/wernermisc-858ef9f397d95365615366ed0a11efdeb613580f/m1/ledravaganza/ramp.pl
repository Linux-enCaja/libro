#!/usr/bin/perl
$BASE = 0xe0009000;
print sprintf("medit 0x%x 0\n", $BASE);
$v = 1;
for ($i = 1; $i != 24; $i++) {
	print sprintf("medit 0x%x %d\n", $BASE+$i*4, $v < $i ? $i : $v);
	$v *= 1.2866;	# int(B^22) = 255
}
