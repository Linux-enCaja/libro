/*
 * comm.h - Fakefile IPC functions
 *
 * Copyright 2012 by Werner Almesberger
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 */

#ifndef COMM_H
#define COMM_H

#include <sys/types.h>


#define	FAKEFILE_MASTER_OUT_VAR	"FAKEFILE_MASTER_OUT"
#define	FAKEFILE_MASTER_IN_VAR	"FAKEFILE_MASTER_IN"


struct fakefile_peer;
struct fakefile_msg;

struct fakefile_peer *fakefile_peer(int in, int out);
void fakefile_peer_close(struct fakefile_peer *peer);
int fakefile_peer_fd(const struct fakefile_peer *peer);

struct fakefile_msg *fakefile_msg_new(struct fakefile_peer *peer,
    int size);
struct fakefile_msg *fakefile_msg_recv(struct fakefile_peer *peer);
void fakefile_msg_end(struct fakefile_msg *msg);

void fakefile_msg_add(struct fakefile_msg *msg, const void *buf, size_t len);
void fakefile_msg_get(struct fakefile_msg *msg, void *buf, size_t len);


#define	decl_add(type)						\
	static inline void fakefile_msg_add_##type(		\
	    struct fakefile_msg *msg, type value)		\
	{							\
		fakefile_msg_add(msg, &value, sizeof(value));	\
	}

#define	decl_get(type)						\
	static inline type fakefile_msg_get_##type(		\
	    struct fakefile_msg *msg)				\
	{							\
		type value;					\
								\
		fakefile_msg_get(msg, &value, sizeof(value));	\
		return value;					\
	}

#define	decl_access(type)	decl_add(type) decl_get(type)

decl_access(int)
decl_access(size_t)
decl_access(ssize_t)

#undef decl_add
#undef decl_get
#undef decl_access

#endif /* !COMM_H */
