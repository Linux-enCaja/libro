/*
 * fakefile.h - Programmed file system illusion
 *
 * Copyright 2012 by Werner Almesberger
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 */

#ifndef FAKEFILE_H
#define FAKEFILE_H

#include <sys/types.h>
#include <sys/stat.h>


enum fakefile_event_type {
	ff_et_exit,
	ff_et_open,
	ff_et_read,
	ff_et_write,
	ff_et_close,
	ff_et_unlink,
	ff_et_rename,
	ff_et_fstat,
};

struct fakefile_event {
	enum fakefile_event_type type;
	union {
		struct fakefile_exit {
			/* in */
			int status;
		} exit;
		struct fakefile_open {
			/* in */
			char *name;
			int flags;
			int mode;
			/* out */
			void *handle;
			int res; /* < 0: -errno; 0: regular open (in slave) */
		} open;
		struct fakefile_read {
			/* in */
			const void *handle;
			/* in/out */
			void *buf;
			ssize_t len;
		} read;
		struct fakefile_write {
			/* in */
			const void *handle;
			void *buf;
			/* in/out */
			ssize_t len;
		} write;
		struct fakefile_close {
			/* in */
			const void *handle;
			/* out */
			int res;
		} close;
		struct fakefile_unlink {
		} unlink;
		struct fakefile_rename {
		} rename;
		struct fakefile_fstat {
			/* in */
			const void *handle;
			/* out */
			struct stat st;
			int res;
		} fstat;
	} u;
	void *user;
};


struct fakefile *fakefile_execv(const char *path, char *const argv[]);
struct fakefile_event *fakefile_poll(void);
void fakefile_respond(struct fakefile_event *event);
void fakefile_end(struct fakefile *ff);

void fakefile_file(struct fakefile *ff, const char *name,
    const void *in, size_t len, void **out);
void fakefile_antifile(struct fakefile *ff, const char *name);

#endif /* !FAKEFILE_H */
