/*
 * demo.c - Fakefile demo
 *
 * Copyright 2012 by Werner Almesberger
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 */


#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#include "fakefile.h"


static void usage(const char *name)
{
	fprintf(stderr,
	    "usage: %s command [arg ...]\n"
	    "       %s -e path errno command\n"
	    "       %s -f path content command\n",
		name, name, name);
	exit(1);
}


int main(int argc, char **argv)
{
	struct fakefile *ff;
	struct fakefile_event *ev;
	int error = 0;
	const char *path = NULL, *fake = NULL;
	char *end;

	if (argc == 1)
		usage(*argv);
	if (*argv[1] == '-') {
		if (argc < 5)
			usage(*argv);
		path = argv[2];
		switch (argv[1][1]) {
		case 'e':
			error = strtoul(argv[3], &end, 0);
			if (*end)
				usage(*argv);
			break;
		case 'f':
			fake = argv[3];
			break;
		default:
			usage(*argv);
		}
		argv += 3;
	}
	ff = fakefile_execv(argv[1], argv+1);
	while (1) {
		ev = fakefile_poll();
		switch (ev->type) {
		case ff_et_open:
			fprintf(stderr, "\"%s\"\n", ev->u.open.name);
			if (path && !strcmp(ev->u.open.name, path)) {
				if (!fake)
					ev->u.open.res = -error;
			} else {
				ev->u.open.res = 0;
			}
			break;
		case ff_et_read: {
			size_t len, left;

			len = ev->u.read.len;
			left = strlen(fake);
			if (len > left)
				len = left;
			ev->u.read.buf = (void *) fake;
			ev->u.read.len = len;
			fake += len;
			break;
		}
		case ff_et_exit:
			goto out;
		default:
			break;
		}
		fakefile_respond(ev);
	}
out:
	fakefile_end(ff);
	return 0;
}
