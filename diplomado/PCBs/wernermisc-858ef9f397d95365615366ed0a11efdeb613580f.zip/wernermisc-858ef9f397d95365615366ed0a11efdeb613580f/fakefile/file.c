/*
 * file.c - Whole file operations
 *
 * Copyright 2012 by Werner Almesberger
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 */


#include "fakefile.h"
#include "internal.h"


int fakefile_internal_event(struct event *ev)
{
	(void) ev;
	return 0;
}


static void add_file(struct fakefile *ff, const char *name,
    const void *in, size_t len, void **out)
{
	/* ... */
}


void fakefile_file(struct fakefile *ff, const char *name,
    const void *in, size_t len, void **out)
{
	add_file(ff, name, in, len, out);
}


void fakefile_antifile(struct fakefile *ff, const char *name)
{
	add_file(ff, name, NULL, 0, NULL);
}
