#!/usr/bin/python

#
# Read the thermocouple on a PicoTest M3500 connected via USB
#

#
# This uses the tmp library from
# svn.openmoko.org/developers/werner/ahrt/host/tmc/
#

import tmc.instrument, tmc.meter

tmc.instrument.debug_default = False
tmc.meter.debug_default = False
m = tmc.meter.picotest_m3500a()
m.debug = False
print m.query(":MEAS:TCO?")
