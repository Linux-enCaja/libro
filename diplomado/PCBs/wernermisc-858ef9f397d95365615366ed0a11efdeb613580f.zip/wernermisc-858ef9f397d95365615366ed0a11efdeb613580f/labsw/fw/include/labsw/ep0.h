/*
 * include/labsw/ep0.h - EP0 extension protocol
 *
 * Written 2011 by Werner Almesberger
 * Copyright 2011 Werner Almesberger
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 */


#ifndef EP0_H
#define EP0_H

/*
 * Direction	bRequest		wValue		wIndex	wLength
 *
 * ->host	LABSW_ID		-		-	3
 * ->host	LABSW_BUILD		-		-	#bytes
 * host->	LABSW_RESET		-		-	0
 *
 * ->host	LABSW_GET		-		-	2
 * host->	LABSW_SET		values		mask	0
 */

/*
 * EP0 protocol:
 *
 * 0.0	initial release
 */

#define EP0LABSW_MAJOR	0	/* EP0 protocol, major revision */
#define EP0LABSW_MINOR	0	/* EP0 protocol, minor revision */

/*
 * bmRequestType:
 *
 * D7 D6..5 D4...0
 * |  |     |
 * direction (0 = host->dev)
 *    type (2 = vendor)
 *          recipient (0 = device)
 */


#define	LABSW_TO_DEV(req)	(0x40 | (req) << 8)
#define	LABSW_FROM_DEV(req)	(0xc0 | (req) << 8)


enum cntr_requests {
	LABSW_ID		= 0x00,
	LABSW_BUILD,
	LABSW_RESET,
	LABSW_GET		= 0x10,
	LABSW_SET,
};

/*
 * LABSW_GET encoding:
 *
 * byte 0	byte 1
 * 76543210	76543210
 * 0000|||IN_1	00000||BUT_MAIN
 *     ||IN_2	     |BUT_CH1
 *     |IN_3	     BUT_CH2
 *     IN_4
 *
 * LABSW_SET encoding:
 *
 * value/mask
 * fedc.ba98.7654.3210
 * 00|| |||| |||| |||CH1_RELAY
 *   || |||| |||| ||CH1_OPT
 *   || |||| |||| |CH2_RELAY
 *   || |||| |||| CH2_OPT
 *   || |||| |||OUT_1
 *   || |||| ||OUT_2
 *   || |||| |OUT_3
 *   || |||| OUT_4
 *   || |||LED_MAIN_R
 *   || ||LED_MAIN_G
 *   || |LED_CH1_R
 *   || LED_CH1_G
 *   |LED_CH2_R
 *   LED_CH2_G
 */

enum labsw_bit_get0 {
	LABSW_IN1	= 1,
	LABSW_IN2	= 2,
	LABSW_IN3	= 4,
	LABSW_IN4	= 8,
};

enum labsw_bit_get1 {
	LABSW_BUT_MAIN	= 1,
	LABSW_BUT_CH1	= 2,
	LABSW_BUT_CH2	= 4,
};

enum labsw_bit_set {
	LABSW_CH1_RELAY	= 0x0001,
	LABSW_CH1_OPT	= 0x0002,
	LABSW_CH2_RELAY	= 0x0004,
	LABSW_CH2_OPT	= 0x0008,
	LABSW_OUT1	= 0x0010,
	LABSW_OUT2	= 0x0020,
	LABSW_OUT3	= 0x0040,
	LABSW_OUT4	= 0x0080,
	LABSW_MAIN_R	= 0x0100,
	LABSW_MAIN_G	= 0x0200,
	LABSW_CH1_R	= 0x0400,
	LABSW_CH1_G	= 0x0800,
	LABSW_CH2_R	= 0x1000,
	LABSW_CH2_G	= 0x2000,
};

void ep0_init(void);

#endif /* !EP0_H */
