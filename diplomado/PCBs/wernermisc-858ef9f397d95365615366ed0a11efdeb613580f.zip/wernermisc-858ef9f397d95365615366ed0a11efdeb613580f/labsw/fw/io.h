/*
 * io.h - I/O pin assignment
 *
 * Written 2011 by Werner Almesberger
 * Copyright 2011 Werner Almesberger
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 */


#ifndef IO_H
#define IO_H

#define	IN_1		P0_0
#define	IN_2		P0_1
#define	IN_4		P0_2
#define	IN_3		P0_3

#define	BUT_MAIN	P0_5
#define	BUT_CH1		P0_6
#define	BUT_CH2		P0_7

#define	LED_CH1_R	P1_0
#define	LED_CH1_G	P1_1
#define	LED_CH2_R	P1_2
#define	LED_CH2_G	P1_3
#define	LED_MAIN_R	P1_4
#define	LED_MAIN_G	P1_5

#define	CH1_RELAY	P2_0
#define	CH2_RELAY	P2_1
#define	CH2_OPT		P2_2
#define	CH1_OPT		P2_3

#define	OUT_1		P2_4
#define	OUT_2		P2_5
#define	OUT_3		P2_6
#define	OUT_4		P2_7

#endif /* !IO_H */
