/*
 * labsw/ep0.c - EP0 extension protocol
 *
 * Written 2008-2011 by Werner Almesberger
 * Copyright 2008-2011 Werner Almesberger
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 */


#include <stdint.h>

#ifndef NULL
#define NULL 0
#endif

#include "regs.h"
#include "usb.h"
#include "labsw/ep0.h"
#include "io.h"
#include "version.h"


extern int local;


/*
 * SDCC 2.8.0 had a number of code generation bugs that appeared in the big
 * switch statement of my_setup. SDCC_FORCE_UPDATE forced the value of the
 * "size" variable to be written to memory. This work-around doesn't seem
 * to be necessary with 2.9.0, but we keep it around, just in case.
 *
 * Unfortunately, the setup->bRequest garbling bug is still with us. Without
 * the evaluation forced with SDCC_FORCE_EVAL, sdcc gets confused about the
 * value of setup->bRequest and then rejects all SETUP requests.
 */

#define	SDCC_FORCE_EVAL(type, value)	\
    do {				\
	static volatile type foo;	\
	foo = value;			\
    } while (0)

#define	SDCC_FORCE_UPDATE(type, var)	\
    do {				\
	volatile type foo;		\
	foo = var;			\
	var = foo;			\
    } while (0)


static uint8_t id[3] = {
	EP0LABSW_MAJOR, EP0LABSW_MINOR,
	/* hw type is set at run time */
};

static __xdata uint8_t buf[128];


#define	BUILD_OFFSET	7	/* '#' plus "65535" plus ' ' */


static __bit my_setup(struct setup_request *setup) __reentrant
{
	uint32_t tmp;
	uint8_t size, i;

	switch (setup->bmRequestType | setup->bRequest << 8) {
	case LABSW_FROM_DEV(LABSW_ID):
		size = setup->wLength;
		if (size > 3)
			size = 3;
		id[2] = 0; /* hardware type */
		usb_send(&ep0, id, size, NULL, NULL);
		return 1;
	case LABSW_FROM_DEV(LABSW_BUILD):
		tmp = build_number;
		for (i = BUILD_OFFSET-2; tmp; i--) {
			buf[i] = (tmp % 10)+'0';
			tmp /= 10;
		}
		buf[i] = '#';
		buf[BUILD_OFFSET-1] = ' ';
		for (size = 0; build_date[size]; size++)
			buf[BUILD_OFFSET+size] = build_date[size];
		size += BUILD_OFFSET-i+1;
		SDCC_FORCE_EVAL(uint8_t, setup->bRequest);
		if (size > setup->wLength)
			return 0;
		usb_send(&ep0, buf+i, size, NULL, NULL);
		return 1;

	case LABSW_TO_DEV(LABSW_RESET):
		RSTSRC = SWRSF;
		while (1);

	case LABSW_FROM_DEV(LABSW_GET):
		size = setup->wLength;
		if (size > 2)
			size = 2;
		buf[0] =
		    (IN_1 ? 0 : LABSW_IN1) |
		    (IN_2 ? 0 : LABSW_IN2) |
		    (IN_3 ? 0 : LABSW_IN3) |
		    (IN_4 ? 0 : LABSW_IN4);
		buf[1] =
		    (BUT_MAIN ? 0 : LABSW_BUT_MAIN) |
		    (BUT_CH1 ? 0 : LABSW_BUT_CH1) |
		    (BUT_CH2 ? 0 : LABSW_BUT_CH2);
		usb_send(&ep0, buf, size, NULL, NULL);
		return 1;

	case LABSW_TO_DEV(LABSW_SET):
		local = !setup->wIndex;

		if (setup->wIndex & LABSW_CH1_RELAY)
			CH1_RELAY = setup->wValue & LABSW_CH1_RELAY ? 1 : 0;
		if (setup->wIndex & LABSW_CH1_OPT)
			CH1_OPT = setup->wValue & LABSW_CH1_OPT ? 0 : 1;
		if (setup->wIndex & LABSW_CH2_RELAY)
			CH2_RELAY = setup->wValue & LABSW_CH2_RELAY ? 1 : 0;
		if (setup->wIndex & LABSW_CH2_OPT)
			CH2_OPT = setup->wValue & LABSW_CH2_OPT ? 0 : 1;
		
		if (setup->wIndex & LABSW_OUT1)
			OUT_1 = setup->wValue & LABSW_OUT1 ? 0 : 1;
		if (setup->wIndex & LABSW_OUT2)
			OUT_2 = setup->wValue & LABSW_OUT2 ? 0 : 1;
		if (setup->wIndex & LABSW_OUT3)
			OUT_3 = setup->wValue & LABSW_OUT3 ? 0 : 1;
		if (setup->wIndex & LABSW_OUT4)
			OUT_4 = setup->wValue & LABSW_OUT4 ? 0 : 1;

		if (setup->wIndex & LABSW_MAIN_R)
			LED_MAIN_R = setup->wValue & LABSW_MAIN_R ? 1 : 0;
		if (setup->wIndex & LABSW_MAIN_G)
			LED_MAIN_G = setup->wValue & LABSW_MAIN_G ? 1 : 0;
		if (setup->wIndex & LABSW_CH1_R)
			LED_CH1_R = setup->wValue & LABSW_CH1_R ? 1 : 0;
		if (setup->wIndex & LABSW_CH1_G)
			LED_CH1_G = setup->wValue & LABSW_CH1_G ? 1 : 0;
		if (setup->wIndex & LABSW_CH2_R)
			LED_CH2_R = setup->wValue & LABSW_CH2_R ? 1 : 0;
		if (setup->wIndex & LABSW_CH2_G)
			LED_CH2_G = setup->wValue & LABSW_CH2_G ? 1 : 0;
		return 1;

	default:
		return 0;
	}
}


void ep0_init(void)
{
	user_setup = my_setup;
}
